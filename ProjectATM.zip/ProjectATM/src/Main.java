import machine.ATM;
import people.User;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ATM atm = new ATM();

        System.out.println("Welcome to the ATM.\nPress Enter Key to insert your ATM card.");
        scanner.nextLine(); // Waiting for the user to press Enter key

        System.out.println("Please enter your User ID:");
        String userID = scanner.nextLine();

        System.out.println("Please enter your PIN:");
        String pin = scanner.nextLine();

        if (atm.authenticateUser(userID, pin)) {
            System.out.println("Authentication successful!");

            User user = new User(userID, pin, 1000.0); // Initial balance $1000

            boolean continueOperation = true;
            while (continueOperation) {
                // options for the user
                System.out.println("Select an option:");
                System.out.println("1. Check Balance");
                System.out.println("2. Withdraw Money");
                System.out.println("3. Deposit Money");
                System.out.println("4. Exit");

                int option = scanner.nextInt();
                switch (option) {
                    case 1:
                        atm.checkBalance(user);
                        break;
                    case 2:
                        System.out.println("Enter amount to withdraw:");
                        double withdrawAmount = scanner.nextDouble();
                        atm.withdrawMoney(user, withdrawAmount);
                        break;
                    case 3:
                        System.out.println("Enter amount to deposit:");
                        double depositAmount = scanner.nextDouble();
                        atm.depositMoney(user, depositAmount);
                        break;
                    case 4:
                        System.out.println("Exiting program.");
                        continueOperation = false;
                        break;
                    default:
                        System.out.println("Invalid option.");
                }

                if (continueOperation) {
                    System.out.println("Press 'C' to continue or 'E' to exit:");
                    char choice = scanner.next().charAt(0);
                    if (choice == 'E' || choice == 'e') {
                        System.out.println("Exiting program.");
                        break;
                    }
                }
            }
        } else {
            System.out.println("Authentication failed. Please try again.");
        }

        scanner.close();
    }
}
